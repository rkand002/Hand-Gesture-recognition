Myo Data Capture
----------------

This is a simple data collection application that will log the EMG and IMU data from a Myo armband to timestamped files in the same directory.

It will only work with one armband. If it re-connects to an armband, it will create a new set of log files.

You will also need the Microsoft Visual Studio 2013 runtime, if you do not have it already:

http://www.microsoft.com/en-gb/download/details.aspx?id=40784

If you are still using a 32-bit operating system, you can try the version in the x86 folder.